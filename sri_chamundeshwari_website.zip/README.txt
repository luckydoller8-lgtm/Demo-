Sri Chamundeshwari Hardware & Electricals website

Your website is in index.html. It is mobile-friendly and includes the product cards,
category filters, click-to-call, and WhatsApp enquiry links.

IMPORTANT:
- The WhatsApp links currently use 93532 02661 (India format +91).
- Check that this is the correct WhatsApp number before publishing.
- No street address or map has been added because one was not provided.
- This folder must be uploaded to a static website host to get a public URL.
